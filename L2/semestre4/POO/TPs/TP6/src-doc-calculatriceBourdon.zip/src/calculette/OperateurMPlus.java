/*Sert à rien */
package calculette;
import java.math.BigDecimal;

public class OperateurMPlus extends Operateur {
	//private int priorite = 2; 
    //private char valeur = ' ';
    private BigDecimal sauvegarde = new BigDecimal(0);
	
	/*public int getPriorite() {
		return priorite;
	}

	public char getValeur() {
		return valeur;
	}*/

	public void evaluer(Pile<BigDecimal> d) {
	}

}
